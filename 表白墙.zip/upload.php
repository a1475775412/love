<?php

/******************************************************************************
参数说明:
$max_file_size  : 上传文件大小限制, 单位BYTE
$destination_folder : 上传文件路径
$watermark   : 是否附加水印(1为加水印,其他为不加水印);
使用说明:
1. 将PHP.INI文件里面的"extension=php_gd2.dll"一行前面的;号去掉,因为我们要用到GD库;
2. 将extension_dir =改为你的php_gd2.dll所在目录;
 ******************************************************************************/
//上传文件类型列表
$uptypes=array(
    'image/jpg',
    'image/jpeg',
    'image/png',
);
$max_file_size=5000000;     //上传文件大小限制, 单位BYTE
$destination_folder="uploads/".date("Y-m")."/"; //上传文件路径
$watermark=1;      //是否附加水印(1为加水印,其他为不加水印);
$watertype=1;      //水印类型(1为文字,2为图片)
$waterposition=1;     //水印位置(1为左下角,2为右下角,3为左上角,4为右上角,5为居中);
$waterstring="http://www.xplore.cn/";  //水印字符串
$waterimg="xplore.gif";    //水印图片
$imgpreview=1;      //是否生成预览图(1为生成,其他为不生成);
$imgpreviewsize=1/2;    //缩略图比例

if (!is_uploaded_file($_FILES["file"][tmp_name])){//是否存在文件
    echo "图片不存在!";
    exit;
}

$file = $_FILES["file"];
if($max_file_size < $file["size"]){//检查文件大小
    exit(json_encode(array('code'=>101,'msg'=>'文件太大')));
}

if(!in_array($file["type"], $uptypes)){ //检查文件类型
    exit(json_encode(array('code'=>102,'msg'=>'文件类型不符'.$file["type"])));
}

if(!file_exists($destination_folder)){
    if(!mkdir($destination_folder,0777,true)){
        exit(json_encode(array('code'=>105,'msg'=>'请确保uploads目录可写权限')));
    }
}

$filename=$file["tmp_name"];
$image_size = getimagesize($filename);
$pinfo=pathinfo($file["name"]);
$ftype=$pinfo['extension'];
$destination = $destination_folder.time().".".$ftype;
if (file_exists($destination)){
    exit(json_encode(array('code'=>103,'msg'=>'同名文件已经存在了')));
}

if(!move_uploaded_file ($filename, $destination)){
    exit(json_encode(array('code'=>104,'msg'=>'移动文件出错')));
}

$pinfo=pathinfo($destination);
$fname=$pinfo[basename];

function image_png_size_add($imgsrc,$imgdst){
    list($width,$height,$type)=getimagesize($imgsrc);
    $new_width = ($width>600?600:$width)*0.9;
    $new_height =($height>900?900:$height)*0.9;
    switch($type){
        case 2:
            header('Content-Type:image/jpeg');
            $image_wp=imagecreatetruecolor($new_width, $new_height);
            $image = imagecreatefromjpeg($imgsrc);
            imagecopyresampled($image_wp, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
            imagejpeg($image_wp, $imgdst,75);
            imagedestroy($image_wp);
            break;
        case 3:
            header('Content-Type:image/png');
            $image_wp=imagecreatetruecolor($new_width, $new_height);
            $image = imagecreatefrompng($imgsrc);
            imagecopyresampled($image_wp, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
            imagejpeg($image_wp, $imgdst,75);
            imagedestroy($image_wp);
            break;
    }
}

image_png_size_add($destination_folder.$fname,$destination_folder.$fname);

exit(json_encode(array('code'=>100,'msg'=>$destination_folder.$fname)));
//echo " <font color=red>已经成功上传</font><br>文件名:  <font color=blue>".$destination_folder.$fname."</font><br>";
//echo " 宽度:".$image_size[0];
//echo " 长度:".$image_size[1];
//echo "<br> 大小:".$file["size"]." bytes";

?>