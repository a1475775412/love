-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2018-02-24 23:11:56
-- 服务器版本： 5.5.57-log
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biaobai_jyan_si`
--

-- --------------------------------------------------------

--
-- 表的结构 `ty_ghistory`
--

CREATE TABLE IF NOT EXISTS `ty_ghistory` (
  `id` int(10) unsigned NOT NULL,
  `ip` char(32) NOT NULL,
  `ttime` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ty_ghistory`
--

INSERT INTO `ty_ghistory` (`id`, `ip`, `ttime`) VALUES
(1, '116.230.19.7', 1519484456);

-- --------------------------------------------------------

--
-- 表的结构 `ty_info`
--

CREATE TABLE IF NOT EXISTS `ty_info` (
  `id` int(1) NOT NULL,
  `sitename` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `noticflag` int(1) DEFAULT NULL,
  `notic` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `about` text CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

--
-- 转存表中的数据 `ty_info`
--

INSERT INTO `ty_info` (`id`, `sitename`, `noticflag`, `notic`, `about`) VALUES
(0, '樱花の白猫大学告白墙', 1, '', ''),
(1, '', NULL, '这是公告', '&lt;h2&gt;&lt;font size=&quot;5&quot;&gt;关于我们&lt;/font&gt;&lt;/h2&gt;&lt;h2&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;你好，欢迎关注樱花の白猫！&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;font size=&quot;3&quot; style=&quot;font-weight: normal;&quot;&gt;欢迎使樱花の白猫&lt;/font&gt;&lt;span style=&quot;font-size: medium; font-weight: normal;&quot;&gt;微信告白墙！&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;我们是樱花の白猫&lt;/font&gt;&lt;/span&gt;&lt;span style=&quot;font-size: medium; font-weight: normal;&quot;&gt;新媒体中心。&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;我们同时运营了“大学”官方新浪微博、“大学新媒体中心”新浪微博。欢迎关注这些账号。&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;如果你对我们感兴趣，欢迎加入我们。&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;我们的秘密基地在：图书馆1楼西侧。&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;/h2&gt;&lt;h2&gt;&lt;font size=&quot;5&quot;&gt;程序特性&lt;/font&gt;&lt;/h2&gt;&lt;h2&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;1.为了节省服务器资源，告白者头像随机显示，不可指定或上传&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;2.发言请遵守当地法律法规和学校规章制度，齐鲁工业大学保留对于发布不良信息和人身攻击的自然人追究法律责任的权利。&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;3.如发现有消息对个人生活产生困扰或想要获取告白者的联系方式，请联系新媒体中心。&lt;/font&gt;&lt;/span&gt;&lt;/p&gt;&lt;/h2&gt;&lt;h2&gt;&lt;font size=&quot;5&quot;&gt;关于本告白墙作者&lt;/font&gt;&lt;/h2&gt;&lt;h2&gt;&lt;p&gt;&lt;span style=&quot;font-weight: normal;&quot;&gt;&lt;font size=&quot;3&quot;&gt;你好，我是樱花の白猫&lt;/font&gt;&lt;/span&gt;&lt;span style=&quot;font-size: medium; font-weight: normal;&quot;&gt;的老成员，这个程序是基于thinkphp+ajax实现的告白墙程序，由于时间紧张，程序的疏漏之处在所难免，如果你有发现任何错误或者有任何建议，欢迎与我联系。联系方式微信:18321668956(如不在线忙碌请留言)&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;font size=&quot;3&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;淘宝：&lt;a href=&quot;樱花の白猫&quot; target=&quot;_blank&quot;&gt;樱花の白猫&lt;/a&gt;&amp;nbsp;&lt;/span&gt;&lt;/font&gt;&lt;/h2&gt;&lt;p&gt;&lt;font size=&quot;3&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;微博：&lt;a href=&quot;https://weibo.com/mj123hb/profile&quot; target=&quot;_blank&quot;&gt;樱花の白猫&lt;/a&gt;&lt;/span&gt;&lt;/font&gt;&lt;/p&gt;&lt;p&gt;微信:18321668956&lt;/p&gt;&lt;p&gt;&lt;font size=&quot;3&quot;&gt;QQ：1950973996&lt;/font&gt;&lt;/p&gt;&lt;p&gt;&lt;font size=&quot;3&quot;&gt;&lt;br&gt;&lt;/font&gt;&lt;/p&gt;&lt;p&gt;&lt;font size=&quot;3&quot;&gt;&lt;a href=&quot;https://item.taobao.com/item.htm?id=564995046530&quot; target=&quot;_blank&quot;&gt;购买本程序源码&lt;/a&gt;&lt;/font&gt;&lt;/p&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;'),
(2, 'admin', NULL, 'admin', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `ty_message`
--

CREATE TABLE IF NOT EXISTS `ty_message` (
  `id` int(11) NOT NULL,
  `realname` varchar(25) NOT NULL,
  `towho` text NOT NULL,
  `ip` text,
  `content` text NOT NULL,
  `lastdate` datetime DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `zan` int(1) unsigned zerofill NOT NULL DEFAULT '0',
  `avatar` varchar(32) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ty_message`
--

INSERT INTO `ty_message` (`id`, `realname`, `towho`, `ip`, `content`, `lastdate`, `email`, `zan`, `avatar`) VALUES
(1, '樱花の白猫', '爱你一万年', '116.230.19.7', '爱你一万年爱你一万年爱你一万年', '2018-02-24 23:00:56', '1950973996@qq.com', 1, '1950973996');

-- --------------------------------------------------------

--
-- 表的结构 `ty_reply`
--

CREATE TABLE IF NOT EXISTS `ty_reply` (
  `id` int(1) unsigned NOT NULL,
  `gid` int(1) unsigned NOT NULL,
  `email` char(32) NOT NULL,
  `reply` text NOT NULL,
  `nname` varchar(30) NOT NULL,
  `status` int(1) unsigned zerofill NOT NULL,
  `ttime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `ty_zan`
--

CREATE TABLE IF NOT EXISTS `ty_zan` (
  `id` int(10) unsigned NOT NULL,
  `ip` char(32) NOT NULL,
  `gid` int(11) NOT NULL,
  `time` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ty_zan`
--

INSERT INTO `ty_zan` (`id`, `ip`, `gid`, `time`) VALUES
(1, '116.230.19.7', 1, 1519484744);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ty_ghistory`
--
ALTER TABLE `ty_ghistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ty_info`
--
ALTER TABLE `ty_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ty_message`
--
ALTER TABLE `ty_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ty_reply`
--
ALTER TABLE `ty_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ty_zan`
--
ALTER TABLE `ty_zan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ty_ghistory`
--
ALTER TABLE `ty_ghistory`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ty_message`
--
ALTER TABLE `ty_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ty_reply`
--
ALTER TABLE `ty_reply`
  MODIFY `id` int(1) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ty_zan`
--
ALTER TABLE `ty_zan`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

ALTER TABLE `ty_message` ADD `imgurl` VARCHAR(500) NULL DEFAULT NULL AFTER `avatar`;
